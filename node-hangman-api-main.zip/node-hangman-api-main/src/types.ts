export type Locale = 'fr-FR' | 'en-GB';
